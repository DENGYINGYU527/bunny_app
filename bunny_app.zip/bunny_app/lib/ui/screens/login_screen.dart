import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/providers/auth_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _emailCtl = TextEditingController();
  final _passCtl = TextEditingController();
  bool _isSignUp = false;
  bool _isLoading = false;
  String? _error;

  Future<void> _submit() async {
    final auth = context.read<AuthProvider>();
    setState(() {
      _error = null;
      _isLoading = true;
    });
    try {
      if (_isSignUp) {
        await auth.signUpWithEmail(_emailCtl.text.trim(), _passCtl.text.trim());
      } else {
        await auth.signInWithEmail(_emailCtl.text.trim(), _passCtl.text.trim());
      }
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('登录成功，正在进入...'), duration: Duration(seconds: 1)),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString());
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('登录失败：$_error')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _skipLogin() async {
    final auth = context.read<AuthProvider>();
    setState(() {
      _error = null;
      _isLoading = true;
    });
    try {
      await auth.signInAnonymously();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('已进入本地体验模式'), duration: Duration(seconds: 1)),
        );
      }
    } catch (e) {
      if (mounted) {
        setState(() => _error = e.toString());
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('进入失败：$_error')),
        );
      }
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text('🐰', style: TextStyle(fontSize: 64)),
              const SizedBox(height: 16),
              const Text('Bunny', textAlign: TextAlign.center, style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('你的私人全能助手', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
              const SizedBox(height: 40),
              TextField(
                controller: _emailCtl,
                decoration: const InputDecoration(labelText: '邮箱'),
                keyboardType: TextInputType.emailAddress,
                enabled: !_isLoading,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _passCtl,
                decoration: const InputDecoration(labelText: '密码'),
                obscureText: true,
                enabled: !_isLoading,
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Text(_error!, style: const TextStyle(color: Colors.red)),
                ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _isLoading ? null : _submit,
                child: _isLoading
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                    : Text(_isSignUp ? '注册' : '登录'),
              ),
              TextButton(
                onPressed: _isLoading ? null : () => setState(() => _isSignUp = !_isSignUp),
                child: Text(_isSignUp ? '已有账号？去登录' : '没有账号？去注册'),
              ),
              const SizedBox(height: 12),
              OutlinedButton(
                onPressed: _isLoading ? null : _skipLogin,
                child: const Text('暂不登录，先体验'),
              ),
              if (!auth.useFirebase)
                const Padding(
                  padding: EdgeInsets.only(top: 16),
                  child: Text(
                    '当前为本地模式。如需云端同步，请配置 Firebase 后再登录。',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
