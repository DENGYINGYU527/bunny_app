# Bunny 个人全能助手

支持 Android + Windows 双平台的原生 Flutter 应用。

## 功能

- 底部 4 Tab：To Do List、开心、实事、美客多
- 登录/注册（Firebase / 本地模式自动降级）
- To Do：多级任务、项目/标签、截止时间、提醒、重复任务、四象限/日历视图、归档
- 开心：每日一文（meiriyiwen.com API），支持换一篇、收藏、分享
- 实事：人民网 + 新华网 RSS 每日精选
- 美客多：Google News RSS 巴西站卖家资讯，含影响解读与标签分级
- AI 总结：按时间段总结已完成任务，导出 PDF / Word
- 任务本地提醒（Android / Windows）
- 敏感数据本地 AES 加密

## 运行前准备

1. 安装 Flutter SDK、Android Studio（Android SDK）或 Visual Studio（Windows 桌面）。
2. 执行：

```bash
flutter pub get
flutter run
```

## Firebase 云端同步（可选）

当前 `lib/firebase_options.dart` 为占位配置，应用启动失败会自动降级到本地模式。

要启用真正的云端同步：

1. 在 [Firebase 控制台](https://console.firebase.google.com/) 创建项目。
2. 安装 FlutterFire CLI：`dart pub global activate flutterfire_cli`
3. 运行：`flutterfire configure`
4. 重新编译应用。

## 数据来源说明

- 每日一文：`https://interface.meiriyiwen.com/article/today?dev=1`
- 人民网 RSS：`http://www.people.com.cn/rss/ywkx.xml`
- 新华网 RSS：`http://www.xinhuanet.com/politics/news_politics.xml`
- 美客多 Google News RSS：巴西葡萄牙语搜索结果

> 抓取内容仅供个人学习使用，请遵守各站 robots 协议与版权规范。
