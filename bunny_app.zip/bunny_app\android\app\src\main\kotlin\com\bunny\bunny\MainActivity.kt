package com.bunny.bunny

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
