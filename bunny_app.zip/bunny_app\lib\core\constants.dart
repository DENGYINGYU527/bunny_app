enum TaskStatus { pending, completed, archived }

enum Priority { high, medium, low }

enum RepeatType { none, daily, weekly, monthly, custom }

enum ContentType { article, audio, video }

enum ContentTab { happy, news, mercado }

enum ImpactLevel { urgent, important, normal }

enum TodoView { today, tomorrow, week, calendar, quadrant }

extension PriorityLabel on Priority {
  String get label {
    switch (this) {
      case Priority.high:
        return '高';
      case Priority.medium:
        return '中';
      case Priority.low:
        return '低';
    }
  }
}

extension RepeatTypeLabel on RepeatType {
  String get label {
    switch (this) {
      case RepeatType.none:
        return '不重复';
      case RepeatType.daily:
        return '每天';
      case RepeatType.weekly:
        return '每周';
      case RepeatType.monthly:
        return '每月';
      case RepeatType.custom:
        return '自定义';
    }
  }
}

extension ImpactLevelLabel on ImpactLevel {
  String get label {
    switch (this) {
      case ImpactLevel.urgent:
        return '紧急';
      case ImpactLevel.important:
        return '重要';
      case ImpactLevel.normal:
        return '普通';
    }
  }
}
