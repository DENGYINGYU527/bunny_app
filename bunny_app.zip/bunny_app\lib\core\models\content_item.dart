enum ContentType { article, audio, video }

enum ContentSource { happy, news, mercado }

enum ImpactLevel { urgent, important, normal }

class ContentItem {
  final String id;
  final ContentType type;
  final ContentSource source;
  final String title;
  final String? summary;
  final String body;
  final String? imageUrl;
  final String? audioUrl;
  final String? videoUrl;
  final String linkUrl;
  final String category;
  final DateTime publishedAt;
  bool isRead;
  bool isFavorite;
  final ImpactLevel impactLevel;
  final String? impactAnalysis;
  final List<String> tags;
  final String language;

  ContentItem({
    required this.id,
    required this.type,
    required this.source,
    required this.title,
    this.summary,
    required this.body,
    this.imageUrl,
    this.audioUrl,
    this.videoUrl,
    required this.linkUrl,
    this.category = '',
    required this.publishedAt,
    this.isRead = false,
    this.isFavorite = false,
    this.impactLevel = ImpactLevel.normal,
    this.impactAnalysis,
    this.tags = const [],
    this.language = 'zh',
  });

  factory ContentItem.fromJson(Map<String, dynamic> json) => ContentItem(
        id: json['id'] as String,
        type: ContentType.values.byName(json['type'] as String),
        source: ContentSource.values.byName(json['source'] as String),
        title: json['title'] as String,
        summary: json['summary'] as String?,
        body: json['body'] as String,
        imageUrl: json['imageUrl'] as String?,
        audioUrl: json['audioUrl'] as String?,
        videoUrl: json['videoUrl'] as String?,
        linkUrl: json['linkUrl'] as String,
        category: json['category'] as String? ?? '',
        publishedAt: DateTime.parse(json['publishedAt'] as String),
        isRead: json['isRead'] as bool? ?? false,
        isFavorite: json['isFavorite'] as bool? ?? false,
        impactLevel: ImpactLevel.values.byName(json['impactLevel'] as String? ?? 'normal'),
        impactAnalysis: json['impactAnalysis'] as String?,
        tags: (json['tags'] as List<dynamic>?)?.cast<String>() ?? [],
        language: json['language'] as String? ?? 'zh',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'type': type.name,
        'source': source.name,
        'title': title,
        'summary': summary,
        'body': body,
        'imageUrl': imageUrl,
        'audioUrl': audioUrl,
        'videoUrl': videoUrl,
        'linkUrl': linkUrl,
        'category': category,
        'publishedAt': publishedAt.toIso8601String(),
        'isRead': isRead,
        'isFavorite': isFavorite,
        'impactLevel': impactLevel.name,
        'impactAnalysis': impactAnalysis,
        'tags': tags,
        'language': language,
      };

  ContentItem copyWith({
    bool? isRead,
    bool? isFavorite,
  }) =>
      ContentItem(
        id: id,
        type: type,
        source: source,
        title: title,
        summary: summary,
        body: body,
        imageUrl: imageUrl,
        audioUrl: audioUrl,
        videoUrl: videoUrl,
        linkUrl: linkUrl,
        category: category,
        publishedAt: publishedAt,
        isRead: isRead ?? this.isRead,
        isFavorite: isFavorite ?? this.isFavorite,
        impactLevel: impactLevel,
        impactAnalysis: impactAnalysis,
        tags: tags,
        language: language,
      );
}
