class Tag {
  final String id;
  final String name;
  final int colorValue;

  Tag({required this.id, required this.name, required this.colorValue});

  factory Tag.fromJson(Map<String, dynamic> json) => Tag(
        id: json['id'] as String,
        name: json['name'] as String,
        colorValue: json['colorValue'] as int,
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'colorValue': colorValue,
      };

  Tag copyWith({String? name, int? colorValue}) => Tag(
        id: id,
        name: name ?? this.name,
        colorValue: colorValue ?? this.colorValue,
      );
}
