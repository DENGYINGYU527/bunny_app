import 'dart:convert';

enum TaskStatus { pending, completed, archived }

enum Priority { high, medium, low }

enum RepeatType { none, daily, weekly, monthly, custom }

class ChecklistItem {
  final String id;
  String title;
  bool isDone;

  ChecklistItem({required this.id, required this.title, this.isDone = false});

  factory ChecklistItem.fromJson(Map<String, dynamic> json) => ChecklistItem(
        id: json['id'] as String,
        title: json['title'] as String,
        isDone: json['isDone'] as bool? ?? false,
      );

  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'isDone': isDone};
}

class RepeatRule {
  final RepeatType type;
  final int? customDays;
  final bool clearContentOnRepeat;

  RepeatRule({required this.type, this.customDays, this.clearContentOnRepeat = false});

  factory RepeatRule.fromJson(Map<String, dynamic> json) => RepeatRule(
        type: RepeatType.values.byName(json['type'] as String),
        customDays: json['customDays'] as int?,
        clearContentOnRepeat: json['clearContentOnRepeat'] as bool? ?? false,
      );

  Map<String, dynamic> toJson() => {
        'type': type.name,
        'customDays': customDays,
        'clearContentOnRepeat': clearContentOnRepeat,
      };
}

class Task {
  final String id;
  String title;
  String description;
  String? projectId;
  String? parentId;
  Priority priority;
  List<String> tagIds;
  DateTime? dueDate;
  Duration? reminderOffset;
  RepeatRule repeatRule;
  List<ChecklistItem> checklist;
  List<String> attachmentUrls;
  TaskStatus status;
  DateTime createdAt;
  DateTime updatedAt;
  DateTime? completedAt;

  Task({
    required this.id,
    required this.title,
    this.description = '',
    this.projectId,
    this.parentId,
    this.priority = Priority.medium,
    this.tagIds = const [],
    this.dueDate,
    this.reminderOffset,
    RepeatRule? repeatRule,
    this.checklist = const [],
    this.attachmentUrls = const [],
    this.status = TaskStatus.pending,
    required this.createdAt,
    required this.updatedAt,
    this.completedAt,
  }) : repeatRule = repeatRule ?? RepeatRule(type: RepeatType.none);

  bool get isCompleted => status == TaskStatus.completed || status == TaskStatus.archived;

  factory Task.fromJson(Map<String, dynamic> json) => Task(
        id: json['id'] as String,
        title: json['title'] as String,
        description: json['description'] as String? ?? '',
        projectId: json['projectId'] as String?,
        parentId: json['parentId'] as String?,
        priority: Priority.values.byName(json['priority'] as String? ?? 'medium'),
        tagIds: (json['tagIds'] as List<dynamic>?)?.cast<String>() ?? [],
        dueDate: json['dueDate'] == null ? null : DateTime.parse(json['dueDate'] as String),
        reminderOffset: json['reminderOffset'] == null
            ? null
            : Duration(minutes: json['reminderOffset'] as int),
        repeatRule: json['repeatRule'] == null
            ? RepeatRule(type: RepeatType.none)
            : RepeatRule.fromJson(json['repeatRule'] as Map<String, dynamic>),
        checklist: (json['checklist'] as List<dynamic>?)
                ?.map((e) => ChecklistItem.fromJson(e as Map<String, dynamic>))
                .toList() ??
            [],
        attachmentUrls: (json['attachmentUrls'] as List<dynamic>?)?.cast<String>() ?? [],
        status: TaskStatus.values.byName(json['status'] as String? ?? 'pending'),
        createdAt: DateTime.parse(json['createdAt'] as String),
        updatedAt: DateTime.parse(json['updatedAt'] as String),
        completedAt: json['completedAt'] == null
            ? null
            : DateTime.parse(json['completedAt'] as String),
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'projectId': projectId,
        'parentId': parentId,
        'priority': priority.name,
        'tagIds': tagIds,
        'dueDate': dueDate?.toIso8601String(),
        'reminderOffset': reminderOffset?.inMinutes,
        'repeatRule': repeatRule.toJson(),
        'checklist': checklist.map((e) => e.toJson()).toList(),
        'attachmentUrls': attachmentUrls,
        'status': status.name,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
        'completedAt': completedAt?.toIso8601String(),
      };

  Task copyWith({
    String? title,
    String? description,
    String? projectId,
    String? parentId,
    Priority? priority,
    List<String>? tagIds,
    DateTime? dueDate,
    Duration? reminderOffset,
    RepeatRule? repeatRule,
    List<ChecklistItem>? checklist,
    List<String>? attachmentUrls,
    TaskStatus? status,
    DateTime? updatedAt,
    DateTime? completedAt,
  }) =>
      Task(
        id: id,
        title: title ?? this.title,
        description: description ?? this.description,
        projectId: projectId ?? this.projectId,
        parentId: parentId ?? this.parentId,
        priority: priority ?? this.priority,
        tagIds: tagIds ?? this.tagIds,
        dueDate: dueDate ?? this.dueDate,
        reminderOffset: reminderOffset ?? this.reminderOffset,
        repeatRule: repeatRule ?? this.repeatRule,
        checklist: checklist ?? this.checklist,
        attachmentUrls: attachmentUrls ?? this.attachmentUrls,
        status: status ?? this.status,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
        completedAt: completedAt ?? this.completedAt,
      );

  String toJsonString() => jsonEncode(toJson());
}
