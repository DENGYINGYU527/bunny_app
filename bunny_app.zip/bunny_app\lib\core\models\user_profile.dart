class UserProfile {
  final String uid;
  final String? email;
  final String? displayName;
  final String? photoUrl;
  final bool isAnonymous;

  UserProfile({
    required this.uid,
    this.email,
    this.displayName,
    this.photoUrl,
    this.isAnonymous = false,
  });

  factory UserProfile.fromFirebaseUser(dynamic user) => UserProfile(
        uid: user.uid as String,
        email: user.email as String?,
        displayName: user.displayName as String?,
        photoUrl: user.photoURL as String?,
        isAnonymous: user.isAnonymous as bool? ?? false,
      );

  factory UserProfile.local({required String uid, String? email, String? displayName}) =>
      UserProfile(
        uid: uid,
        email: email,
        displayName: displayName,
        isAnonymous: true,
      );
}
