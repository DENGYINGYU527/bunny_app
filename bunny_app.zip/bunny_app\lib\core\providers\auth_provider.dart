import 'package:flutter/foundation.dart';
import '../models/user_profile.dart';
import '../services/auth_service.dart';

class AuthProvider extends ChangeNotifier {
  final AuthService _auth;
  UserProfile? _user;

  AuthProvider(this._auth);

  UserProfile? get user => _user;
  bool get isSignedIn => _user != null;
  bool get useFirebase => _auth.useFirebase;

  Future<void> init() async {
    await _auth.init();
    _user = _auth.currentUser;
    _auth.authStateChanges.listen((u) {
      _user = u;
      notifyListeners();
    });
    notifyListeners();
  }

  Future<void> signInAnonymously() async {
    _user = await _auth.signInAnonymously();
    notifyListeners();
  }

  Future<void> signInWithEmail(String email, String password) async {
    _user = await _auth.signInWithEmailAndPassword(email, password);
    notifyListeners();
  }

  Future<void> signUpWithEmail(String email, String password) async {
    _user = await _auth.signUpWithEmailAndPassword(email, password);
    notifyListeners();
  }

  Future<void> signOut() async {
    await _auth.signOut();
    _user = null;
    notifyListeners();
  }
}
