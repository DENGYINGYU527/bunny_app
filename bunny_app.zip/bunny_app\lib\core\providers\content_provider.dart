import 'package:flutter/foundation.dart';
import '../models/content_item.dart';
import '../services/content_repository.dart';

class ContentProvider extends ChangeNotifier {
  final ContentRepository _repo;
  ContentProvider(this._repo);

  final Map<ContentSource, List<ContentItem>> _items = {};
  final Map<ContentSource, bool> _loading = {};
  final Map<ContentSource, String?> _errors = {};

  List<ContentItem> items(ContentSource source) => _items[source] ?? [];
  bool isLoading(ContentSource source) => _loading[source] ?? false;
  String? error(ContentSource source) => _errors[source];

  Future<void> load(ContentSource source, {bool refresh = false}) async {
    _loading[source] = true;
    _errors[source] = null;
    notifyListeners();
    try {
      final list = await _repo.fetch(source, refresh: refresh);
      _items[source] = list;
    } catch (e) {
      _errors[source] = e.toString();
    } finally {
      _loading[source] = false;
      notifyListeners();
    }
  }

  Future<void> refreshRandomHappy() async {
    _loading[ContentSource.happy] = true;
    notifyListeners();
    try {
      final item = await _repo.fetchRandomHappy();
      _items[ContentSource.happy] = [item];
    } catch (e) {
      _errors[ContentSource.happy] = e.toString();
    } finally {
      _loading[ContentSource.happy] = false;
      notifyListeners();
    }
  }

  Future<void> toggleFavorite(ContentItem item) async {
    await _repo.toggleFavorite(item);
    notifyListeners();
  }

  Future<void> markRead(ContentItem item) async {
    await _repo.markRead(item);
    notifyListeners();
  }

  List<ContentItem> favorites() {
    return _items.values.expand((list) => list).where((i) => i.isFavorite).toList();
  }
}
