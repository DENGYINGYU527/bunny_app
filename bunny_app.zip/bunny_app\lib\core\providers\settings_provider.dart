import 'package:flutter/foundation.dart';
import '../services/settings_service.dart';

class SettingsProvider extends ChangeNotifier {
  final SettingsService _service;
  SettingsProvider(this._service);

  int _lastTabIndex = 0;
  int get lastTabIndex => _lastTabIndex;

  Future<void> load() async {
    _lastTabIndex = await _service.getLastTabIndex();
    notifyListeners();
  }

  Future<void> setLastTabIndex(int index) async {
    _lastTabIndex = index;
    await _service.setLastTabIndex(index);
    notifyListeners();
  }
}
