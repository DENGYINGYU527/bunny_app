import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import '../models/project.dart';
import '../models/tag.dart';
import '../models/task.dart';
import '../services/notification_service.dart';
import '../services/task_repository.dart';

enum TaskView { today, tomorrow, week, calendar, quadrant, history }

class TaskProvider extends ChangeNotifier {
  final TaskRepository _repo;
  final NotificationService _notifications;

  TaskProvider(this._repo, this._notifications);

  bool _loaded = false;
  TaskView _view = TaskView.today;
  String? _selectedProjectId;
  Priority? _selectedPriority;
  List<String> _selectedTagIds = [];
  DateTime _selectedDate = DateTime.now();

  TaskView get view => _view;
  DateTime get selectedDate => _selectedDate;
  List<Task> get tasks => _repo.tasks;
  List<Project> get projects => _repo.projects;
  List<Tag> get tags => _repo.tags;

  Future<void> load() async {
    if (_loaded) return;
    await _repo.load();
    _loaded = true;
    notifyListeners();
  }

  void setView(TaskView view) {
    _view = view;
    notifyListeners();
  }

  void setFilters({String? projectId, Priority? priority, List<String>? tagIds}) {
    _selectedProjectId = projectId;
    _selectedPriority = priority;
    _selectedTagIds = tagIds ?? [];
    notifyListeners();
  }

  void setSelectedDate(DateTime date) {
    _selectedDate = date;
    notifyListeners();
  }

  List<Task> get visibleTasks {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    switch (_view) {
      case TaskView.today:
        return _filtered(_repo.query(
          dueOnOrAfter: today,
          dueBefore: today.add(const Duration(days: 1)),
          topLevel: true,
        ));
      case TaskView.tomorrow:
        final t = today.add(const Duration(days: 1));
        return _filtered(_repo.query(
          dueOnOrAfter: t,
          dueBefore: t.add(const Duration(days: 1)),
          topLevel: true,
        ));
      case TaskView.week:
        return _filtered(_repo.query(
          dueOnOrAfter: today,
          dueBefore: today.add(const Duration(days: 7)),
          topLevel: true,
        ));
      case TaskView.calendar:
        return _filtered(_repo.query(
          dueOnOrAfter: _selectedDate,
          dueBefore: _selectedDate.add(const Duration(days: 1)),
          topLevel: true,
        ));
      case TaskView.quadrant:
        return _filtered(_repo.query(topLevel: true)
          ..sort((a, b) => _quadrantRank(a).compareTo(_quadrantRank(b))));
      case TaskView.history:
        return _filtered(_repo.query(status: TaskStatus.archived));
    }
  }

  List<Task> _filtered(List<Task> list) {
    return list.where((t) {
      if (_selectedProjectId != null && t.projectId != _selectedProjectId) return false;
      if (_selectedPriority != null && t.priority != _selectedPriority) return false;
      if (_selectedTagIds.isNotEmpty && !_selectedTagIds.any((id) => t.tagIds.contains(id))) return false;
      return true;
    }).toList();
  }

  int _quadrantRank(Task t) {
    // Urgent = due within 2 days, Important = high priority
    final urgent = t.dueDate != null && t.dueDate!.difference(DateTime.now()).inDays <= 2;
    final important = t.priority == Priority.high;
    if (urgent && important) return 0;
    if (!urgent && important) return 1;
    if (urgent && !important) return 2;
    return 3;
  }

  String countdownText(Task task) {
    if (task.dueDate == null) return '无截止日期';
    final diff = task.dueDate!.difference(DateTime.now()).inDays;
    final date = DateFormat('MM月dd日').format(task.dueDate!);
    if (diff < 0) return '截止 $date，已逾期 ${-diff} 天';
    if (diff == 0) return '截止 $date，剩余 0 天（今天）';
    return '截止 $date，剩余 $diff 天';
  }

  Future<void> addTask(Task task) async {
    await _repo.addTask(task);
    await _notifications.scheduleTaskReminder(task);
    notifyListeners();
  }

  Future<void> updateTask(Task task) async {
    await _repo.updateTask(task.copyWith(updatedAt: DateTime.now()));
    await _notifications.scheduleTaskReminder(task);
    notifyListeners();
  }

  Future<void> deleteTask(String id) async {
    await _repo.deleteTask(id);
    await _notifications.cancel(id);
    notifyListeners();
  }

  Future<void> toggleComplete(Task task) async {
    final now = DateTime.now();
    final isCompleted = !task.isCompleted;
    final updated = task.copyWith(
      status: isCompleted ? TaskStatus.completed : TaskStatus.pending,
      completedAt: isCompleted ? now : null,
      updatedAt: now,
    );
    await _repo.updateTask(updated);
    if (isCompleted && task.repeatRule.type != RepeatType.none) {
      await _spawnNextOccurrence(task);
    }
    notifyListeners();
  }

  Future<void> _spawnNextOccurrence(Task task) async {
    final nextDue = _nextDueDate(task.dueDate, task.repeatRule);
    if (nextDue == null) return;
    final newTask = Task(
      id: '${task.id}_next_${DateTime.now().millisecondsSinceEpoch}',
      title: task.title,
      description: task.repeatRule.clearContentOnRepeat ? '' : task.description,
      projectId: task.projectId,
      parentId: task.parentId,
      priority: task.priority,
      tagIds: List.from(task.tagIds),
      dueDate: nextDue,
      reminderOffset: task.reminderOffset,
      repeatRule: task.repeatRule,
      checklist: task.repeatRule.clearContentOnRepeat
          ? []
          : task.checklist.map((c) => ChecklistItem(id: '${c.id}_n', title: c.title)).toList(),
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
    );
    await _repo.addTask(newTask);
    await _notifications.scheduleTaskReminder(newTask);
  }

  DateTime? _nextDueDate(DateTime? due, RepeatRule rule) {
    if (due == null) return null;
    switch (rule.type) {
      case RepeatType.daily:
        return due.add(const Duration(days: 1));
      case RepeatType.weekly:
        return due.add(const Duration(days: 7));
      case RepeatType.monthly:
        return DateTime(due.year, due.month + 1, due.day, due.hour, due.minute);
      case RepeatType.custom:
        if (rule.customDays == null) return null;
        return due.add(Duration(days: rule.customDays!));
      case RepeatType.none:
        return null;
    }
  }

  Future<void> archiveTask(String id) async {
    await _repo.archiveCompleted(id);
    notifyListeners();
  }

  Future<void> restoreTask(String id) async {
    await _repo.restoreArchived(id);
    notifyListeners();
  }

  Future<void> addProject(String name, int color) async {
    await _repo.addProject(Project(
      id: 'proj_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      colorValue: color,
      createdAt: DateTime.now(),
    ));
    notifyListeners();
  }

  Future<void> addTag(String name, int color) async {
    await _repo.addTag(Tag(
      id: 'tag_${DateTime.now().millisecondsSinceEpoch}',
      name: name,
      colorValue: color,
    ));
    notifyListeners();
  }

  Future<void> refreshReminders() async {
    for (final t in _repo.tasks) {
      await _notifications.scheduleTaskReminder(t);
    }
  }
}
