import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import '../models/task.dart';
import 'settings_service.dart';

class AiService {
  final SettingsService _settings;
  AiService(this._settings);

  Future<String> generateTaskSummary(
    List<Task> tasks, {
    required DateTime from,
    required DateTime to,
  }) async {
    if (tasks.isEmpty) return '该时间段内没有已完成的任务。';

    final apiKey = await _settings.getLlmApiKey();
    if (apiKey != null && apiKey.isNotEmpty) {
      try {
        return await _callLlm(tasks, from, to, apiKey);
      } catch (_) {
        // fall back to local template
      }
    }
    return _localSummary(tasks, from, to);
  }

  Future<String> _callLlm(
    List<Task> tasks,
    DateTime from,
    DateTime to,
    String apiKey,
  ) async {
    const endpoint = 'https://api.openai.com/v1/chat/completions';
    const model = 'gpt-4o-mini';
    final prompt = _buildPrompt(tasks, from, to);

    final res = await http.post(
      Uri.parse(endpoint),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: jsonEncode({
        'model': model,
        'messages': [
          {'role': 'system', 'content': '你是一位高效的个人助理，擅长把任务清单整理成清晰的工作总结。'},
          {'role': 'user', 'content': prompt},
        ],
        'temperature': 0.5,
      }),
    );

    if (res.statusCode != 200) throw Exception('LLM request failed');
    final body = jsonDecode(res.body);
    return body['choices'][0]['message']['content'] as String;
  }

  String _buildPrompt(List<Task> tasks, DateTime from, DateTime to) {
    final df = DateFormat('yyyy-MM-dd');
    final buffer = StringBuffer(
      '请根据以下 ${tasks.length} 条在 ${df.format(from)} 至 ${df.format(to)} 期间已完成的任务，按项目/分类/时间维度进行分点总结，输出为一份工作回顾文档：\n\n',
    );
    for (final t in tasks) {
      buffer.writeln('- [${t.priority.name}] ${t.title}');
      if (t.description.isNotEmpty) buffer.writeln('  备注：${t.description}');
      if (t.completedAt != null) buffer.writeln('  完成时间：${df.format(t.completedAt!)}');
    }
    return buffer.toString();
  }

  String _localSummary(List<Task> tasks, DateTime from, DateTime to) {
    final df = DateFormat('yyyy-MM-dd');
    final byPriority = <Priority, List<Task>>{};
    for (final t in tasks) {
      byPriority.putIfAbsent(t.priority, () => []).add(t);
    }
    final buffer = StringBuffer();
    buffer.writeln('🐰 Bunny 任务总结 (${df.format(from)} ~ ${df.format(to)})');
    buffer.writeln('');
    buffer.writeln('本周期共完成 ${tasks.length} 项任务。');
    buffer.writeln('');
    byPriority.forEach((p, list) {
      buffer.writeln('## ${p.label}（${list.length} 项）');
      for (final t in list) {
        buffer.writeln('- ${t.title}${t.completedAt != null ? '（${df.format(t.completedAt!)}）' : ''}');
      }
      buffer.writeln('');
    });
    buffer.writeln('---\n注：当前使用本地模板总结。在设置中填写 OpenAI API Key 后可启用 AI 深度总结。');
    return buffer.toString();
  }
}

extension on Priority {
  String get label {
    switch (this) {
      case Priority.high:
        return '高优先级';
      case Priority.medium:
        return '中优先级';
      case Priority.low:
        return '低优先级';
    }
  }
}
