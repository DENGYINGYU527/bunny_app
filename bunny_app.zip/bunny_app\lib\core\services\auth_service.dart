import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import '../../firebase_options.dart';
import '../models/user_profile.dart';
import 'settings_service.dart';

class AuthService {
  final SettingsService _settings;
  AuthService(this._settings);

  bool _useFirebase = false;
  UserProfile? _localUser;

  Future<void> init() async {
    try {
      await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
      _useFirebase = true;
      await _settings.setUseFirebase(true);
    } catch (e) {
      _useFirebase = false;
      await _settings.setUseFirebase(false);
    }
  }

  bool get useFirebase => _useFirebase;

  UserProfile? get currentUser {
    if (_useFirebase) {
      final user = FirebaseAuth.instance.currentUser;
      return user == null ? null : UserProfile.fromFirebaseUser(user);
    }
    return _localUser;
  }

  Stream<UserProfile?> get authStateChanges {
    if (_useFirebase) {
      return FirebaseAuth.instance.authStateChanges().map(
            (u) => u == null ? null : UserProfile.fromFirebaseUser(u),
          );
    }
    return Stream.fromIterable([_localUser]);
  }

  Future<UserProfile> signInAnonymously() async {
    if (_useFirebase) {
      final cred = await FirebaseAuth.instance.signInAnonymously();
      return UserProfile.fromFirebaseUser(cred.user!);
    }
    _localUser = UserProfile.local(uid: 'local_${DateTime.now().millisecondsSinceEpoch}');
    return _localUser!;
  }

  Future<UserProfile> signInWithEmailAndPassword(String email, String password) async {
    if (_useFirebase) {
      final cred = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return UserProfile.fromFirebaseUser(cred.user!);
    }
    _localUser = UserProfile.local(uid: 'local_$email', email: email, displayName: email);
    return _localUser!;
  }

  Future<UserProfile> signUpWithEmailAndPassword(String email, String password) async {
    if (_useFirebase) {
      final cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      return UserProfile.fromFirebaseUser(cred.user!);
    }
    _localUser = UserProfile.local(uid: 'local_$email', email: email, displayName: email);
    return _localUser!;
  }

  Future<void> signOut() async {
    if (_useFirebase) {
      await FirebaseAuth.instance.signOut();
    } else {
      _localUser = null;
    }
  }
}
