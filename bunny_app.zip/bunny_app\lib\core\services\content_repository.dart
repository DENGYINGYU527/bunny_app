import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:html/parser.dart' show parse;
import 'package:xml/xml.dart';
import '../models/content_item.dart';
import 'storage_service.dart';

class ContentRepository {
  final StorageService _storage;
  ContentRepository(this._storage);

  final Map<ContentSource, List<ContentItem>> _cache = {};

  static const _happyBase = 'https://interface.meiriyiwen.com/article';
  static const _newsSources = [
    'http://www.people.com.cn/rss/ywkx.xml',
    'http://www.xinhuanet.com/politics/news_politics.xml',
  ];
  static const _mercadoRss =
      'https://news.google.com/rss/search?q=Mercado+Libre+vendedor+Brasil&hl=pt-BR&gl=BR&ceid=BR:pt-419';

  Future<List<ContentItem>> fetch(ContentSource source, {bool refresh = false}) async {
    if (!refresh && _cache.containsKey(source)) return _cache[source]!;

    List<ContentItem> items = [];
    try {
      switch (source) {
        case ContentSource.happy:
          items = await _fetchHappy();
          break;
        case ContentSource.news:
          items = await _fetchNews();
          break;
        case ContentSource.mercado:
          items = await _fetchMercado();
          break;
      }
    } catch (e) {
      items = [];
    }

    final saved = await _loadSavedStates(source);
    final merged = _mergeStates(items, saved);
    _cache[source] = merged;
    return merged;
  }

  Future<List<ContentItem>> _fetchHappy() async {
    final res = await http.get(Uri.parse('$_happyBase/today?dev=1'));
    if (res.statusCode != 200) return [];
    final data = jsonDecode(res.body)['data'];
    if (data == null) return [];
    final htmlBody = data['content'] as String? ?? '';
    final textBody = _htmlToText(htmlBody);
    return [
      ContentItem(
        id: 'happy_${data['date']?['curr'] ?? DateTime.now().millisecondsSinceEpoch}',
        type: ContentType.article,
        source: ContentSource.happy,
        title: data['title'] as String? ?? '每日一文',
        body: textBody,
        linkUrl: 'https://www.meiriyiwen.com',
        category: '每日一文',
        publishedAt: DateTime.now(),
        language: 'zh',
      )
    ];
  }

  Future<ContentItem> fetchRandomHappy() async {
    final res = await http.get(Uri.parse('$_happyBase/random?dev=1'));
    final data = jsonDecode(res.body)['data'];
    final htmlBody = data['content'] as String? ?? '';
    final textBody = _htmlToText(htmlBody);
    return ContentItem(
      id: 'happy_random_${DateTime.now().millisecondsSinceEpoch}',
      type: ContentType.article,
      source: ContentSource.happy,
      title: data['title'] as String? ?? '随机一文',
      body: textBody,
      linkUrl: 'https://www.meiriyiwen.com',
      category: '随机推荐',
      publishedAt: DateTime.now(),
      language: 'zh',
    );
  }

  Future<List<ContentItem>> _fetchNews() async {
    final List<ContentItem> all = [];
    for (final url in _newsSources) {
      try {
        final res = await http.get(Uri.parse(url));
        if (res.statusCode != 200) continue;
        final doc = XmlDocument.parse(utf8.decode(res.bodyBytes));
        final items = doc.findAllElements('item');
        for (final item in items.take(15)) {
          final title = _elementText(item, 'title');
          final link = _elementText(item, 'link');
          final desc = _elementText(item, 'description');
          final pubDate = _elementText(item, 'pubDate');
          if (title.isEmpty || link.isEmpty) continue;
          all.add(ContentItem(
            id: 'news_${link.hashCode}',
            type: ContentType.article,
            source: ContentSource.news,
            title: title,
            summary: desc.isEmpty ? null : _htmlToText(desc),
            body: desc.isEmpty ? title : _htmlToText(desc),
            linkUrl: link,
            category: _categorizeNews(title + desc),
            publishedAt: _parseRssDate(pubDate) ?? DateTime.now(),
            language: 'zh',
          ));
        }
      } catch (_) {}
    }
    all.sort((a, b) => b.publishedAt.compareTo(a.publishedAt));
    return all.toSet().toList();
  }

  Future<List<ContentItem>> _fetchMercado() async {
    final res = await http.get(Uri.parse(_mercadoRss));
    if (res.statusCode != 200) return [];
    final doc = XmlDocument.parse(utf8.decode(res.bodyBytes));
    final items = doc.findAllElements('item');
    return items.take(20).map((item) {
      final title = _elementText(item, 'title');
      final link = _elementText(item, 'link');
      final desc = _elementText(item, 'description');
      final pubDate = _elementText(item, 'pubDate');
      final level = _mercadoImpactLevel(title + desc);
      return ContentItem(
        id: 'meli_${link.hashCode}',
        type: ContentType.article,
        source: ContentSource.mercado,
        title: title,
        summary: desc.isEmpty ? null : _htmlToText(desc),
        body: desc.isEmpty ? title : _htmlToText(desc),
        linkUrl: link,
        category: _mercadoCategory(title + desc),
        publishedAt: _parseRssDate(pubDate) ?? DateTime.now(),
        impactLevel: level,
        impactAnalysis: _mercadoImpactAnalysis(title, level),
        language: 'pt',
      );
    }).toList();
  }

  Future<void> toggleFavorite(ContentItem item) async {
    item.isFavorite = !item.isFavorite;
    await _saveState(item);
  }

  Future<void> markRead(ContentItem item) async {
    item.isRead = true;
    await _saveState(item);
  }

  Future<void> _saveState(ContentItem item) async {
    final key = 'content_state_${item.source.name}_${item.id}';
    await _storage.setString(key, jsonEncode({'isRead': item.isRead, 'isFavorite': item.isFavorite}));
  }

  Future<Map<String, Map<String, dynamic>>> _loadSavedStates(ContentSource source) async {
    // Simplified: states are saved per item on demand; cache holds them after merge.
    return {};
  }

  List<ContentItem> _mergeStates(List<ContentItem> items, Map<String, Map<String, dynamic>> states) {
    return items.map((item) {
      final state = states[item.id];
      if (state == null) return item;
      return item.copyWith(
        isRead: state['isRead'] as bool?,
        isFavorite: state['isFavorite'] as bool?,
      );
    }).toList();
  }

  String _elementText(XmlElement item, String name) {
    final elem = item.findElements(name).firstOrNull;
    return elem?.innerText.trim() ?? '';
  }

  String _htmlToText(String html) {
    final doc = parse(html);
    return doc.body?.text.trim() ?? html;
  }

  DateTime? _parseRssDate(String? text) {
    if (text == null || text.isEmpty) return null;
    try {
      return DateTime.parse(text);
    } catch (_) {
      return null;
    }
  }

  String _categorizeNews(String text) {
    final lower = text.toLowerCase();
    if (lower.contains('科技') || lower.contains('ai') || lower.contains('人工智能')) return '科技';
    if (lower.contains('财经') || lower.contains('经济') || lower.contains('金融')) return '财经';
    if (lower.contains('国际') || lower.contains('美国') || lower.contains('世界')) return '国际';
    if (lower.contains('社会') || lower.contains('民生')) return '社会';
    return '时政';
  }

  String _mercadoCategory(String text) {
    final lower = text.toLowerCase();
    if (lower.contains('tax') || lower.contains('fee') || lower.contains('comiss') || lower.contains('cust')) return '平台费用';
    if (lower.contains('log') || lower.contains('envio') || lower.contains('entrega') || lower.contains('full')) return '物流动态';
    if (lower.contains('promo') || lower.contains('sale') || lower.contains('black friday') || lower.contains('hot sale')) return '促销活动';
    if (lower.contains('pol') || lower.contains('regr') || lower.contains('proib') || lower.contains('norm')) return '平台政策';
    return '平台动态';
  }

  ImpactLevel _mercadoImpactLevel(String text) {
    final lower = text.toLowerCase();
    if (lower.contains('urgente') || lower.contains('proibi') || lower.contains('ban') || lower.contains('suspens')) {
      return ImpactLevel.urgent;
    }
    if (lower.contains('fee') || lower.contains('comiss') || lower.contains('log') || lower.contains('envio')) {
      return ImpactLevel.important;
    }
    return ImpactLevel.normal;
  }

  String _mercadoImpactAnalysis(String title, ImpactLevel level) {
    switch (level) {
      case ImpactLevel.urgent:
        return '该政策/变动可能直接影响店铺正常运营，建议尽快登录卖家后台确认并调整。';
      case ImpactLevel.important:
        return '该资讯涉及费用、物流或促销，建议评估对利润和运营策略的影响。';
      case ImpactLevel.normal:
        return '常规平台动态，可了解后按需调整运营计划。';
    }
  }
}
