import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:encrypt/encrypt.dart' as encrypt;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class EncryptionService {
  static const _keyName = 'bunny_encryption_key';
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  encrypt.Key? _key;

  Future<void> init() async {
    String? stored = await _secureStorage.read(key: _keyName);
    if (stored == null || stored.length != 32) {
      final random = Random.secure();
      final bytes = Uint8List(32);
      for (int i = 0; i < 32; i++) {
        bytes[i] = random.nextInt(256);
      }
      _key = encrypt.Key(bytes);
      await _secureStorage.write(key: _keyName, value: base64Encode(bytes));
    } else {
      _key = encrypt.Key(base64Decode(stored));
    }
  }

  String encryptText(String plain) {
    if (_key == null) throw StateError('EncryptionService not initialized');
    final iv = encrypt.IV.fromLength(16);
    final enc = encrypt.Encrypter(encrypt.AES(_key!, mode: encrypt.AESMode.cbc));
    final encrypted = enc.encrypt(plain, iv: iv);
    return base64Encode(iv.bytes + encrypted.bytes);
  }

  String decryptText(String cipher) {
    if (_key == null) throw StateError('EncryptionService not initialized');
    final bytes = base64Decode(cipher);
    final iv = encrypt.IV(Uint8List.fromList(bytes.sublist(0, 16)));
    final data = encrypt.Encrypted(Uint8List.fromList(bytes.sublist(16)));
    final enc = encrypt.Encrypter(encrypt.AES(_key!, mode: encrypt.AESMode.cbc));
    return utf8.decode(enc.decryptBytes(data, iv: iv));
  }
}
