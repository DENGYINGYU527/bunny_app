import 'package:docs_gee/docs_gee.dart';

class ExportService {
  Future<List<int>> generatePdf(String title, String content) async {
    final doc = _buildDocument(title, content);
    return PdfGenerator().generate(doc);
  }

  Future<List<int>> generateDocx(String title, String content) async {
    final doc = _buildDocument(title, content);
    return DocxGenerator().generate(doc);
  }

  Document _buildDocument(String title, String content) {
    final doc = Document(title: title, author: 'Bunny');
    doc.addParagraph(Paragraph.heading(title, level: 1));
    for (final line in content.split('\n')) {
      if (line.trim().isEmpty) continue;
      if (line.startsWith('## ')) {
        doc.addParagraph(Paragraph.heading(line.substring(3), level: 2));
      } else if (line.startsWith('- ')) {
        doc.addParagraph(Paragraph.bulletItem(line.substring(2)));
      } else {
        doc.addParagraph(Paragraph.text(line));
      }
    }
    return doc;
  }
}
