import 'package:flutter_local_notifications/flutter_local_notifications.dart' as fln;
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import '../models/task.dart';

class NotificationService {
  final fln.FlutterLocalNotificationsPlugin _plugin = fln.FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    tz.initializeTimeZones();

    const androidSettings = fln.AndroidInitializationSettings('@mipmap/ic_launcher');
    const darwinSettings = fln.DarwinInitializationSettings();
    const linuxSettings = fln.LinuxInitializationSettings(defaultActionName: 'Open');
    const windowsSettings = fln.WindowsInitializationSettings(
      appName: 'Bunny',
      appUserModelId: 'com.bunny.Bunny',
      guid: 'a8c3d8f7-1b2c-4d5e-9f0a-1b2c3d4e5f6a',
    );

    const initSettings = fln.InitializationSettings(
      android: androidSettings,
      iOS: darwinSettings,
      macOS: darwinSettings,
      linux: linuxSettings,
      windows: windowsSettings,
    );

    await _plugin.initialize(settings: initSettings);
    _initialized = true;
  }

  Future<void> scheduleTaskReminder(Task task) async {
    await cancel(task.id);
    if (task.dueDate == null || task.reminderOffset == null) return;
    final scheduled = task.dueDate!.subtract(task.reminderOffset!);
    if (scheduled.isBefore(DateTime.now())) return;

    await _plugin.zonedSchedule(
      id: task.id.hashCode,
      title: '任务提醒：${task.title}',
      body: task.description.isEmpty ? '别忘了完成这项任务哦~' : task.description,
      scheduledDate: tz.TZDateTime.from(scheduled, tz.local),
      notificationDetails: const fln.NotificationDetails(
        android: fln.AndroidNotificationDetails(
          'bunny_task_reminders',
          '任务提醒',
          channelDescription: 'Bunny 任务截止时间提醒',
          importance: fln.Importance.high,
          priority: fln.Priority.high,
        ),
      ),
      androidScheduleMode: fln.AndroidScheduleMode.exactAllowWhileIdle,
    );
  }

  Future<void> cancel(String taskId) async {
    await _plugin.cancel(id: taskId.hashCode);
  }

  Future<void> cancelAll() async {
    await _plugin.cancelAll();
  }
}
