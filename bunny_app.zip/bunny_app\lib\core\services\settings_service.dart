import 'storage_service.dart';

class SettingsService {
  final StorageService _storage;
  SettingsService(this._storage);

  static const _lastTabKey = 'last_tab_index';
  static const _useFirebaseKey = 'use_firebase';
  static const _llmApiKeyKey = 'llm_api_key';
  static const _happyTopicsKey = 'happy_topics';

  Future<int> getLastTabIndex() async {
    final raw = await _storage.getString(_lastTabKey);
    return raw == null ? 0 : int.tryParse(raw) ?? 0;
  }

  Future<void> setLastTabIndex(int index) async {
    await _storage.setString(_lastTabKey, index.toString());
  }

  Future<bool> getUseFirebase() async {
    final raw = await _storage.getString(_useFirebaseKey);
    return raw == 'true';
  }

  Future<void> setUseFirebase(bool value) async {
    await _storage.setString(_useFirebaseKey, value.toString());
  }

  Future<String?> getLlmApiKey() async {
    return _storage.getString(_llmApiKeyKey, encrypted: true);
  }

  Future<void> setLlmApiKey(String? key) async {
    if (key == null || key.isEmpty) {
      await _storage.remove(_llmApiKeyKey);
    } else {
      await _storage.setString(_llmApiKeyKey, key, encrypt: true);
    }
  }

  Future<List<String>> getHappyTopics() async {
    final raw = await _storage.getString(_happyTopicsKey);
    if (raw == null || raw.isEmpty) {
      return ['人物传记', '心理疗愈', '哲学思考', '积极心理学', '格局提升'];
    }
    return raw.split(',');
  }

  Future<void> setHappyTopics(List<String> topics) async {
    await _storage.setString(_happyTopicsKey, topics.join(','));
  }
}
