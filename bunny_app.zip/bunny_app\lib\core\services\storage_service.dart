import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'encryption_service.dart';

class StorageService {
  final EncryptionService _encryption;
  SharedPreferences? _prefs;

  StorageService(this._encryption);

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    await _encryption.init();
  }

  Future<void> setString(String key, String value, {bool encrypt = false}) async {
    final prefs = _prefs;
    if (prefs == null) throw StateError('StorageService not initialized');
    final stored = encrypt ? _encryption.encryptText(value) : value;
    await prefs.setString(key, stored);
  }

  Future<String?> getString(String key, {bool encrypted = false}) async {
    final prefs = _prefs;
    if (prefs == null) throw StateError('StorageService not initialized');
    final raw = prefs.getString(key);
    if (raw == null) return null;
    return encrypted ? _encryption.decryptText(raw) : raw;
  }

  Future<void> setObjectList(String key, List<Map<String, dynamic>> list, {bool encrypt = false}) async {
    final jsonString = jsonEncode(list);
    await setString(key, jsonString, encrypt: encrypt);
  }

  Future<List<Map<String, dynamic>>> getObjectList(String key, {bool encrypted = false}) async {
    final raw = await getString(key, encrypted: encrypted);
    if (raw == null || raw.isEmpty) return [];
    final decoded = jsonDecode(raw);
    if (decoded is List) return decoded.cast<Map<String, dynamic>>();
    return [];
  }

  Future<void> remove(String key) async {
    await _prefs?.remove(key);
  }
}
