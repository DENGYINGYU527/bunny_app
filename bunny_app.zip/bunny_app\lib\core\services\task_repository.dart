import '../models/project.dart';
import '../models/tag.dart';
import '../models/task.dart';
import 'storage_service.dart';

class TaskRepository {
  final StorageService _storage;
  TaskRepository(this._storage);

  static const _tasksKey = 'bunny_tasks';
  static const _projectsKey = 'bunny_projects';
  static const _tagsKey = 'bunny_tags';

  List<Task> _tasks = [];
  List<Project> _projects = [];
  List<Tag> _tags = [];

  List<Task> get tasks => List.unmodifiable(_tasks);
  List<Project> get projects => List.unmodifiable(_projects);
  List<Tag> get tags => List.unmodifiable(_tags);

  Future<void> load() async {
    final taskMaps = await _storage.getObjectList(_tasksKey, encrypted: true);
    _tasks = taskMaps.map((m) => Task.fromJson(m)).toList();

    final projectMaps = await _storage.getObjectList(_projectsKey, encrypted: false);
    _projects = projectMaps.map((m) => Project.fromJson(m)).toList();

    final tagMaps = await _storage.getObjectList(_tagsKey, encrypted: false);
    _tags = tagMaps.map((m) => Tag.fromJson(m)).toList();
  }

  Future<void> _saveTasks() async {
    await _storage.setObjectList(_tasksKey, _tasks.map((t) => t.toJson()).toList(), encrypt: true);
  }

  Future<void> _saveProjects() async {
    await _storage.setObjectList(_projectsKey, _projects.map((p) => p.toJson()).toList(), encrypt: false);
  }

  Future<void> _saveTags() async {
    await _storage.setObjectList(_tagsKey, _tags.map((t) => t.toJson()).toList(), encrypt: false);
  }

  Future<void> addTask(Task task) async {
    _tasks.add(task);
    await _saveTasks();
  }

  Future<void> updateTask(Task task) async {
    final idx = _tasks.indexWhere((t) => t.id == task.id);
    if (idx >= 0) {
      _tasks[idx] = task;
      await _saveTasks();
    }
  }

  Future<void> deleteTask(String id) async {
    _tasks.removeWhere((t) => t.id == id || t.parentId == id);
    await _saveTasks();
  }

  Task? getTask(String id) {
    try {
      return _tasks.firstWhere((t) => t.id == id);
    } catch (_) {
      return null;
    }
  }

  List<Task> get children => _tasks.where((t) => t.parentId != null).toList();
  List<Task> childrenOf(String parentId) => _tasks.where((t) => t.parentId == parentId).toList();

  Future<void> addProject(Project project) async {
    _projects.add(project);
    await _saveProjects();
  }

  Future<void> updateProject(Project project) async {
    final idx = _projects.indexWhere((p) => p.id == project.id);
    if (idx >= 0) {
      _projects[idx] = project;
      await _saveProjects();
    }
  }

  Future<void> deleteProject(String id) async {
    _projects.removeWhere((p) => p.id == id);
    for (final t in _tasks) {
      if (t.projectId == id) t.projectId = null;
    }
    await _saveProjects();
    await _saveTasks();
  }

  Future<void> addTag(Tag tag) async {
    _tags.add(tag);
    await _saveTags();
  }

  Future<void> deleteTag(String id) async {
    _tags.removeWhere((t) => t.id == id);
    for (final t in _tasks) {
      t.tagIds.remove(id);
    }
    await _saveTags();
    await _saveTasks();
  }

  List<Task> query({
    TaskStatus? status,
    Priority? priority,
    String? projectId,
    List<String>? tagIds,
    DateTime? dueOnOrAfter,
    DateTime? dueBefore,
    bool? topLevel,
  }) {
    return _tasks.where((t) {
      if (status != null && t.status != status) return false;
      if (priority != null && t.priority != priority) return false;
      if (projectId != null && t.projectId != projectId) return false;
      if (tagIds != null && tagIds.isNotEmpty && !tagIds.any((id) => t.tagIds.contains(id))) return false;
      if (dueOnOrAfter != null && (t.dueDate == null || t.dueDate!.isBefore(dueOnOrAfter))) return false;
      if (dueBefore != null && (t.dueDate == null || !t.dueDate!.isBefore(dueBefore))) return false;
      if (topLevel == true && t.parentId != null) return false;
      return true;
    }).toList();
  }

  Future<void> archiveCompleted(String taskId) async {
    final task = getTask(taskId);
    if (task != null && task.status == TaskStatus.completed) {
      await updateTask(task.copyWith(status: TaskStatus.archived));
    }
  }

  Future<void> restoreArchived(String taskId) async {
    final task = getTask(taskId);
    if (task != null && task.status == TaskStatus.archived) {
      await updateTask(task.copyWith(status: TaskStatus.pending));
    }
  }
}
