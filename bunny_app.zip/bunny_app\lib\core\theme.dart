import 'package:flutter/material.dart';

class AppTheme {
  static const Color primary = Color(0xFFFFA6C9);
  static const Color primaryDark = Color(0xFFFF6FA3);
  static const Color secondary = Color(0xFFFFD966);
  static const Color background = Color(0xFFFFF5F8);
  static const Color surface = Colors.white;
  static const Color text = Color(0xFF4A4A4A);
  static const Color textLight = Color(0xFF888888);
  static const Color highPriority = Color(0xFFFF6B6B);
  static const Color mediumPriority = Color(0xFFFFD166);
  static const Color lowPriority = Color(0xFF06D6A0);
  static const Color urgent = Color(0xFFE63946);
  static const Color important = Color(0xFFF4A261);
  static const Color normal = Color(0xFF8ECAE6);

  static ThemeData get lightTheme {
    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: const ColorScheme.light(
        primary: primary,
        onPrimary: Colors.white,
        secondary: secondary,
        onSecondary: text,
        surface: surface,
        onSurface: text,
        error: highPriority,
      ),
      scaffoldBackgroundColor: background,
      appBarTheme: const AppBarTheme(
        backgroundColor: surface,
        foregroundColor: text,
        elevation: 0,
        centerTitle: true,
      ),
      bottomNavigationBarTheme: const BottomNavigationBarThemeData(
        backgroundColor: surface,
        selectedItemColor: primaryDark,
        unselectedItemColor: textLight,
        type: BottomNavigationBarType.fixed,
        elevation: 8,
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: primaryDark,
        foregroundColor: Colors.white,
      ),
      cardTheme: CardThemeData(
        color: surface,
        elevation: 2,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: surface,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
      ),
      fontFamily: 'Roboto',
    );
  }
}
