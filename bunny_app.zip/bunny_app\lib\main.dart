import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'app.dart';
import 'core/providers/auth_provider.dart';
import 'core/providers/content_provider.dart';
import 'core/providers/settings_provider.dart';
import 'core/providers/task_provider.dart';
import 'core/services/auth_service.dart';
import 'core/services/content_repository.dart';
import 'core/services/encryption_service.dart';
import 'core/services/notification_service.dart';
import 'core/services/settings_service.dart';
import 'core/services/storage_service.dart';
import 'core/services/task_repository.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final encryption = EncryptionService();
  final storage = StorageService(encryption);
  await storage.init();

  final settingsService = SettingsService(storage);
  final authService = AuthService(settingsService);
  await authService.init();

  final taskRepo = TaskRepository(storage);
  final contentRepo = ContentRepository(storage);
  final notifications = NotificationService();
  await notifications.init();

  runApp(
    MultiProvider(
      providers: [
        Provider.value(value: settingsService),
        Provider.value(value: authService),
        Provider.value(value: taskRepo),
        Provider.value(value: contentRepo),
        Provider.value(value: notifications),
        ChangeNotifierProvider(create: (_) => AuthProvider(authService)),
        ChangeNotifierProvider(create: (_) => SettingsProvider(settingsService)..load()),
        ChangeNotifierProvider(create: (_) => TaskProvider(taskRepo, notifications)..load()),
        ChangeNotifierProvider(create: (_) => ContentProvider(contentRepo)),
      ],
      child: const BunnyApp(),
    ),
  );
}
