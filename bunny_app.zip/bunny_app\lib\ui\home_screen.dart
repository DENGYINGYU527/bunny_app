import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/providers/settings_provider.dart';
import 'tabs/happy_tab.dart';
import 'tabs/mercado_tab.dart';
import 'tabs/news_tab.dart';
import 'tabs/todo_tab.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  bool _loaded = false;

  final _pages = const [
    TodoTab(),
    HappyTab(),
    NewsTab(),
    MercadoTab(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final settings = context.read<SettingsProvider>();
      await settings.load();
      setState(() {
        _index = settings.lastTabIndex.clamp(0, 3);
        _loaded = true;
      });
    });
  }

  void _onTap(int idx) {
    setState(() => _index = idx);
    context.read<SettingsProvider>().setLastTabIndex(idx);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _loaded ? IndexedStack(index: _index, children: _pages) : const Center(child: CircularProgressIndicator()),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: _onTap,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.checklist_rounded), label: 'To Do'),
          BottomNavigationBarItem(icon: Icon(Icons.sunny_snowing), label: '开心'),
          BottomNavigationBarItem(icon: Icon(Icons.newspaper_rounded), label: '实事'),
          BottomNavigationBarItem(icon: Icon(Icons.storefront_rounded), label: '美客多'),
        ],
      ),
    );
  }
}
