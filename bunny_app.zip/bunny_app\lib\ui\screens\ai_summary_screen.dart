import 'dart:io';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/models/task.dart';
import '../../core/providers/task_provider.dart';
import '../../core/services/ai_service.dart';
import '../../core/services/export_service.dart';
import '../../core/services/settings_service.dart';

class AiSummaryScreen extends StatefulWidget {
  const AiSummaryScreen({super.key});

  @override
  State<AiSummaryScreen> createState() => _AiSummaryScreenState();
}

class _AiSummaryScreenState extends State<AiSummaryScreen> {
  DateTime _from = DateTime.now().subtract(const Duration(days: 30));
  DateTime _to = DateTime.now();
  String _summary = '';
  bool _loading = false;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TaskProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('AI 总结导出')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(child: _DateTile(label: '开始', date: _from, onChanged: (d) => setState(() => _from = d))),
                const SizedBox(width: 12),
                Expanded(child: _DateTile(label: '结束', date: _to, onChanged: (d) => setState(() => _to = d))),
              ],
            ),
            const SizedBox(height: 12),
            ElevatedButton.icon(
              onPressed: _loading ? null : () => _generate(provider),
              icon: _loading ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_awesome),
              label: Text(_loading ? '生成中...' : '生成 AI 总结'),
            ),
            if (_summary.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 12),
                child: Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _export(provider, 'pdf'),
                        icon: const Icon(Icons.picture_as_pdf),
                        label: const Text('导出 PDF'),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: () => _export(provider, 'docx'),
                        icon: const Icon(Icons.description_outlined),
                        label: const Text('导出 Word'),
                      ),
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 16),
            if (_summary.isEmpty)
              const Expanded(child: Center(child: Text('选择时间段后生成总结')))
            else
              Expanded(
                child: Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: SingleChildScrollView(child: Text(_summary)),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _generate(TaskProvider provider) async {
    setState(() => _loading = true);
    final settings = context.read<SettingsService>();
    final ai = AiService(settings);
    final tasks = provider.tasks.where((t) {
      if (t.status != TaskStatus.completed && t.status != TaskStatus.archived) return false;
      final comp = t.completedAt ?? t.updatedAt;
      return comp.isAfter(_from) && comp.isBefore(_to.add(const Duration(days: 1)));
    }).toList();
    final summary = await ai.generateTaskSummary(tasks, from: _from, to: _to);
    setState(() {
      _summary = summary;
      _loading = false;
    });
  }

  Future<void> _export(TaskProvider provider, String ext) async {
    final export = ExportService();
    final bytes = ext == 'pdf'
        ? await export.generatePdf('Bunny 任务总结', _summary)
        : await export.generateDocx('Bunny 任务总结', _summary);
    final dir = await getApplicationDocumentsDirectory();
    final df = DateFormat('yyyyMMdd');
    final file = File('${dir.path}/bunny_summary_${df.format(_from)}_${df.format(_to)}.$ext');
    await file.writeAsBytes(bytes);
    await SharePlus.instance.share(ShareParams(files: [XFile(file.path)], text: 'Bunny 任务总结'));
  }
}

class _DateTile extends StatelessWidget {
  final String label;
  final DateTime date;
  final ValueChanged<DateTime> onChanged;
  const _DateTile({required this.label, required this.date, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      subtitle: Text(DateFormat('yyyy-MM-dd').format(date)),
      trailing: const Icon(Icons.calendar_today),
      onTap: () async {
        final d = await showDatePicker(
          context: context,
          initialDate: date,
          firstDate: DateTime(2020),
          lastDate: DateTime(2099),
        );
        if (d != null) onChanged(d);
      },
    );
  }
}
