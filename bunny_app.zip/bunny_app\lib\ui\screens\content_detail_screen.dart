import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/models/content_item.dart';
import '../../core/providers/content_provider.dart';
import 'package:provider/provider.dart';

class ContentDetailScreen extends StatelessWidget {
  final ContentItem item;
  const ContentDetailScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ContentProvider>();
    return Scaffold(
      appBar: AppBar(
        title: Text(item.category.isEmpty ? '详情' : item.category),
        actions: [
          IconButton(
            icon: Icon(item.isFavorite ? Icons.favorite : Icons.favorite_border,
                color: item.isFavorite ? Colors.red : null),
            onPressed: () => provider.toggleFavorite(item),
          ),
          IconButton(
            icon: const Icon(Icons.share_outlined),
            onPressed: () => SharePlus.instance.share(ShareParams(text: '${item.title}\n${item.linkUrl}')),
          ),
        ],
      ),
      body: SelectionArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item.title, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 8),
              Text(
                item.publishedAt.toString().substring(0, 16),
                style: const TextStyle(color: Colors.grey),
              ),
              if (item.impactAnalysis != null) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.orange.shade50,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text('影响解读：${item.impactAnalysis}'),
                ),
              ],
              const SizedBox(height: 16),
              Text(item.body, style: const TextStyle(fontSize: 16, height: 1.7)),
              const SizedBox(height: 24),
              if (item.linkUrl.isNotEmpty)
                TextButton.icon(
                  onPressed: () => SharePlus.instance.share(ShareParams(text: item.linkUrl)),
                  icon: const Icon(Icons.link),
                  label: const Text('查看原文'),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
