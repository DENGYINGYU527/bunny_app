import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../../core/models/task.dart';
import '../../core/providers/task_provider.dart';

class TaskEditScreen extends StatefulWidget {
  final Task? task;
  const TaskEditScreen({super.key, this.task});

  @override
  State<TaskEditScreen> createState() => _TaskEditScreenState();
}

class _TaskEditScreenState extends State<TaskEditScreen> {
  late final TextEditingController _titleCtl;
  late final TextEditingController _descCtl;
  late final TextEditingController _customDaysCtl;
  Priority _priority = Priority.medium;
  String? _projectId;
  List<String> _tagIds = [];
  DateTime? _dueDate;
  Duration? _reminderOffset;
  RepeatType _repeat = RepeatType.none;
  bool _clearContent = false;
  int? _customDays;
  final List<ChecklistItem> _checklist = [];

  @override
  void initState() {
    super.initState();
    final t = widget.task;
    _titleCtl = TextEditingController(text: t?.title ?? '');
    _descCtl = TextEditingController(text: t?.description ?? '');
    _priority = t?.priority ?? Priority.medium;
    _projectId = t?.projectId;
    _tagIds = t?.tagIds ?? [];
    _dueDate = t?.dueDate;
    _reminderOffset = t?.reminderOffset;
    _repeat = t?.repeatRule.type ?? RepeatType.none;
    _clearContent = t?.repeatRule.clearContentOnRepeat ?? false;
    _customDays = t?.repeatRule.customDays;
    _customDaysCtl = TextEditingController(text: _customDays?.toString() ?? '');
    if (t != null) _checklist.addAll(t.checklist);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TaskProvider>();
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.task == null ? '新建任务' : '编辑任务'),
        actions: [
          IconButton(
            icon: const Icon(Icons.check),
            onPressed: () => _save(provider),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: _titleCtl,
            decoration: const InputDecoration(labelText: '任务名称'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _descCtl,
            decoration: const InputDecoration(labelText: '描述/备注'),
            maxLines: 3,
          ),
          const SizedBox(height: 16),
          _buildProjectSelector(provider),
          const SizedBox(height: 12),
          _buildPrioritySelector(),
          const SizedBox(height: 12),
          _buildTagSelector(provider),
          const SizedBox(height: 12),
          _buildDateTile(),
          const SizedBox(height: 12),
          _buildReminderTile(),
          const SizedBox(height: 12),
          _buildRepeatSection(),
          const SizedBox(height: 16),
          _buildChecklist(),
        ],
      ),
    );
  }

  Widget _buildProjectSelector(TaskProvider provider) {
    return DropdownButtonFormField<String?>(
      initialValue: _projectId,
      decoration: const InputDecoration(labelText: '所属项目'),
      items: [
        const DropdownMenuItem(value: null, child: Text('无')),
        ...provider.projects.map((p) => DropdownMenuItem(value: p.id, child: Text(p.name))),
      ],
      onChanged: (v) => setState(() => _projectId = v),
    );
  }

  Widget _buildPrioritySelector() {
    return SegmentedButton<Priority>(
      segments: const [
        ButtonSegment(value: Priority.high, label: Text('高')),
        ButtonSegment(value: Priority.medium, label: Text('中')),
        ButtonSegment(value: Priority.low, label: Text('低')),
      ],
      selected: {_priority},
      onSelectionChanged: (s) => setState(() => _priority = s.first),
    );
  }

  Widget _buildTagSelector(TaskProvider provider) {
    if (provider.tags.isEmpty) return const SizedBox.shrink();
    return Wrap(
      spacing: 8,
      children: provider.tags.map((tag) {
        final selected = _tagIds.contains(tag.id);
        return FilterChip(
          label: Text(tag.name),
          selected: selected,
          onSelected: (_) => setState(() {
            selected ? _tagIds.remove(tag.id) : _tagIds.add(tag.id);
          }),
        );
      }).toList(),
    );
  }

  Widget _buildDateTile() {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      title: const Text('截止时间'),
      subtitle: Text(_dueDate == null ? '未设置' : DateFormat('yyyy-MM-dd HH:mm').format(_dueDate!)),
      trailing: const Icon(Icons.calendar_today),
      onTap: () async {
        final date = await showDatePicker(
          context: context,
          initialDate: _dueDate ?? DateTime.now(),
          firstDate: DateTime(2020),
          lastDate: DateTime(2099),
        );
        if (date == null) return;
        if (!mounted) return;
        final time = await showTimePicker(
          context: context,
          initialTime: TimeOfDay.fromDateTime(_dueDate ?? DateTime.now()),
        );
        if (time == null) return;
        setState(() => _dueDate = DateTime(date.year, date.month, date.day, time.hour, time.minute));
      },
    );
  }

  Widget _buildReminderTile() {
    final opts = {
      null: '不提醒',
      const Duration(minutes: 15): '提前 15 分钟',
      const Duration(minutes: 60): '提前 1 小时',
      const Duration(days: 1): '提前 1 天',
    };
    return DropdownButtonFormField<Duration?>(
      initialValue: _reminderOffset,
      decoration: const InputDecoration(labelText: '提醒'),
      items: opts.entries
          .map((e) => DropdownMenuItem(value: e.key, child: Text(e.value)))
          .toList(),
      onChanged: (v) => setState(() => _reminderOffset = v),
    );
  }

  Widget _buildRepeatSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButtonFormField<RepeatType>(
          initialValue: _repeat,
          decoration: const InputDecoration(labelText: '重复'),
          items: RepeatType.values
              .map((r) => DropdownMenuItem(value: r, child: Text(r.label)))
              .toList(),
          onChanged: (v) => setState(() => _repeat = v!),
        ),
        if (_repeat == RepeatType.custom)
          TextField(
            controller: _customDaysCtl,
            decoration: const InputDecoration(labelText: '每 X 天'),
            keyboardType: TextInputType.number,
          ),
        if (_repeat != RepeatType.none)
          CheckboxListTile(
            contentPadding: EdgeInsets.zero,
            title: const Text('下次清空具体内容（保留框架）'),
            value: _clearContent,
            onChanged: (v) => setState(() => _clearContent = v ?? false),
          ),
      ],
    );
  }

  Widget _buildChecklist() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('清单项', style: TextStyle(fontWeight: FontWeight.bold)),
            const Spacer(),
            TextButton.icon(
              onPressed: () => setState(() => _checklist.add(ChecklistItem(
                    id: 'chk_${DateTime.now().millisecondsSinceEpoch}',
                    title: '',
                  ))),
              icon: const Icon(Icons.add),
              label: const Text('添加'),
            ),
          ],
        ),
        ..._checklist.asMap().entries.map((entry) {
          final idx = entry.key;
          final item = entry.value;
          return TextField(
            controller: TextEditingController(text: item.title),
            decoration: InputDecoration(
              hintText: '清单项 ${idx + 1}',
              suffixIcon: IconButton(
                icon: const Icon(Icons.close),
                onPressed: () => setState(() => _checklist.removeAt(idx)),
              ),
            ),
            onChanged: (v) => item.title = v,
          );
        }),
      ],
    );
  }

  Future<void> _save(TaskProvider provider) async {
    final customDays = int.tryParse(_customDaysCtl.text);
    final repeatRule = RepeatRule(
      type: _repeat,
      customDays: _repeat == RepeatType.custom ? customDays : null,
      clearContentOnRepeat: _clearContent,
    );
    final now = DateTime.now();
    final task = widget.task == null
        ? Task(
            id: 'task_${now.millisecondsSinceEpoch}',
            title: _titleCtl.text.trim(),
            description: _descCtl.text.trim(),
            projectId: _projectId,
            priority: _priority,
            tagIds: _tagIds,
            dueDate: _dueDate,
            reminderOffset: _reminderOffset,
            repeatRule: repeatRule,
            checklist: _checklist.where((c) => c.title.trim().isNotEmpty).toList(),
            createdAt: now,
            updatedAt: now,
          )
        : widget.task!.copyWith(
            title: _titleCtl.text.trim(),
            description: _descCtl.text.trim(),
            projectId: _projectId,
            priority: _priority,
            tagIds: _tagIds,
            dueDate: _dueDate,
            reminderOffset: _reminderOffset,
            repeatRule: repeatRule,
            checklist: _checklist.where((c) => c.title.trim().isNotEmpty).toList(),
            updatedAt: now,
          );
    if (widget.task == null) {
      await provider.addTask(task);
    } else {
      await provider.updateTask(task);
    }
    if (mounted) Navigator.pop(context);
  }
}

extension on RepeatType {
  String get label {
    switch (this) {
      case RepeatType.none:
        return '不重复';
      case RepeatType.daily:
        return '每天';
      case RepeatType.weekly:
        return '每周';
      case RepeatType.monthly:
        return '每月';
      case RepeatType.custom:
        return '自定义';
    }
  }
}
