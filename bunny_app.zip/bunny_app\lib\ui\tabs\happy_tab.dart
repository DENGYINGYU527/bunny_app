import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/content_item.dart';
import '../../core/providers/content_provider.dart';
import '../screens/content_detail_screen.dart';

class HappyTab extends StatefulWidget {
  const HappyTab({super.key});

  @override
  State<HappyTab> createState() => _HappyTabState();
}

class _HappyTabState extends State<HappyTab> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ContentProvider>().load(ContentSource.happy);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ContentProvider>();
    final items = provider.items(ContentSource.happy);
    final loading = provider.isLoading(ContentSource.happy);
    final error = provider.error(ContentSource.happy);

    return Scaffold(
      appBar: AppBar(
        title: const Text('开心'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: '换一篇',
            onPressed: () => provider.refreshRandomHappy(),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text('加载失败：$error'))
              : items.isEmpty
                  ? const Center(child: Text('暂无内容'))
                  : _HappyCard(item: items.first),
    );
  }
}

class _HappyCard extends StatelessWidget {
  final ContentItem item;
  const _HappyCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<ContentProvider>();
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(item.title, style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 12),
              Text(item.body, style: const TextStyle(fontSize: 16, height: 1.6)),
              const SizedBox(height: 20),
              Row(
                children: [
                  IconButton(
                    icon: Icon(item.isFavorite ? Icons.favorite : Icons.favorite_border,
                        color: item.isFavorite ? Colors.red : null),
                    onPressed: () => provider.toggleFavorite(item),
                  ),
                  IconButton(
                    icon: const Icon(Icons.share_outlined),
                    onPressed: () {
                      // share
                    },
                  ),
                  const Spacer(),
                  TextButton.icon(
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => ContentDetailScreen(item: item)),
                    ),
                    icon: const Icon(Icons.open_in_full),
                    label: const Text('阅读详情'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
