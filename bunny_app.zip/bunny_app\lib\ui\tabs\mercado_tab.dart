import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/content_item.dart';
import '../../core/providers/content_provider.dart';
import '../screens/content_detail_screen.dart';

class MercadoTab extends StatefulWidget {
  const MercadoTab({super.key});

  @override
  State<MercadoTab> createState() => _MercadoTabState();
}

class _MercadoTabState extends State<MercadoTab> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ContentProvider>().load(ContentSource.mercado);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ContentProvider>();
    final items = provider.items(ContentSource.mercado);
    final loading = provider.isLoading(ContentSource.mercado);
    final error = provider.error(ContentSource.mercado);

    return Scaffold(
      appBar: AppBar(
        title: const Text('美客多'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => provider.load(ContentSource.mercado, refresh: true),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text('加载失败：$error'))
              : items.isEmpty
                  ? const Center(child: Text('暂无美客多资讯'))
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: items.length,
                      itemBuilder: (context, idx) => _MercadoCard(item: items[idx]),
                    ),
    );
  }
}

class _MercadoCard extends StatelessWidget {
  final ContentItem item;
  const _MercadoCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<ContentProvider>();
    Color levelColor;
    String levelText;
    switch (item.impactLevel) {
      case ImpactLevel.urgent:
        levelColor = Colors.red;
        levelText = '紧急';
        break;
      case ImpactLevel.important:
        levelColor = Colors.orange;
        levelText = '重要';
        break;
      case ImpactLevel.normal:
        levelColor = Colors.blue;
        levelText = '普通';
        break;
    }
    return Card(
      child: ListTile(
        leading: Chip(
          label: Text(levelText, style: const TextStyle(color: Colors.white, fontSize: 10)),
          backgroundColor: levelColor,
          padding: EdgeInsets.zero,
          visualDensity: VisualDensity.compact,
        ),
        title: Text(item.title),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('${item.category} · ${item.publishedAt.toString().substring(0, 16)}'),
            if (item.impactAnalysis != null)
              Text(item.impactAnalysis!, style: const TextStyle(fontSize: 12, color: Colors.grey)),
          ],
        ),
        trailing: IconButton(
          icon: Icon(item.isFavorite ? Icons.favorite : Icons.favorite_border,
              color: item.isFavorite ? Colors.red : null),
          onPressed: () => provider.toggleFavorite(item),
        ),
        onTap: () {
          provider.markRead(item);
          Navigator.push(context, MaterialPageRoute(builder: (_) => ContentDetailScreen(item: item)));
        },
      ),
    );
  }
}
