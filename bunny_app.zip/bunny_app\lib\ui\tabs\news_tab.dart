import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/content_item.dart';
import '../../core/providers/content_provider.dart';
import '../screens/content_detail_screen.dart';

class NewsTab extends StatefulWidget {
  const NewsTab({super.key});

  @override
  State<NewsTab> createState() => _NewsTabState();
}

class _NewsTabState extends State<NewsTab> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<ContentProvider>().load(ContentSource.news);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<ContentProvider>();
    final items = provider.items(ContentSource.news);
    final loading = provider.isLoading(ContentSource.news);
    final error = provider.error(ContentSource.news);

    return Scaffold(
      appBar: AppBar(
        title: const Text('实事'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => provider.load(ContentSource.news, refresh: true),
          ),
        ],
      ),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text('加载失败：$error'))
              : items.isEmpty
                  ? const Center(child: Text('暂无新闻'))
                  : ListView.builder(
                      padding: const EdgeInsets.all(12),
                      itemCount: items.length,
                      itemBuilder: (context, idx) => _NewsCard(item: items[idx]),
                    ),
    );
  }
}

class _NewsCard extends StatelessWidget {
  final ContentItem item;
  const _NewsCard({required this.item});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<ContentProvider>();
    return Card(
      child: ListTile(
        leading: item.isRead
            ? const Icon(Icons.check_circle, color: Colors.grey)
            : const Icon(Icons.circle, color: Colors.pinkAccent, size: 12),
        title: Text(
          item.title,
          style: TextStyle(fontWeight: item.isRead ? FontWeight.normal : FontWeight.bold),
        ),
        subtitle: Text('${item.category} · ${item.publishedAt.toString().substring(0, 16)}'),
        trailing: IconButton(
          icon: Icon(item.isFavorite ? Icons.favorite : Icons.favorite_border,
              color: item.isFavorite ? Colors.red : null),
          onPressed: () => provider.toggleFavorite(item),
        ),
        onTap: () {
          provider.markRead(item);
          Navigator.push(context, MaterialPageRoute(builder: (_) => ContentDetailScreen(item: item)));
        },
      ),
    );
  }
}
