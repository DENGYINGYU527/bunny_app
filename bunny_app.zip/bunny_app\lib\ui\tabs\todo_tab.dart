import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/tag.dart';
import '../../core/models/task.dart';
import '../../core/providers/task_provider.dart';
import '../screens/ai_summary_screen.dart';
import '../screens/task_edit_screen.dart';
import '../widgets/calendar_view.dart';
import '../widgets/quadrant_view.dart';

class TodoTab extends StatelessWidget {
  const TodoTab({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TaskProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('To Do List'),
        actions: [
          IconButton(
            icon: const Icon(Icons.summarize_outlined),
            tooltip: 'AI 总结',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const AiSummaryScreen()),
            ),
          ),
          _ViewMenu(),
        ],
      ),
      body: _buildBody(provider),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const TaskEditScreen()),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildBody(TaskProvider provider) {
    if (provider.view == TaskView.calendar) return const CalendarView();
    if (provider.view == TaskView.quadrant) return const QuadrantView();

    final tasks = provider.visibleTasks;
    if (tasks.isEmpty) {
      return const Center(child: Text('暂时没有任务，去添加一个吧 🐰'));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: tasks.length,
      itemBuilder: (context, idx) => _TaskCard(task: tasks[idx]),
    );
  }
}

class _ViewMenu extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final provider = context.read<TaskProvider>();
    return PopupMenuButton<TaskView>(
      icon: const Icon(Icons.filter_list),
      onSelected: provider.setView,
      itemBuilder: (_) => const [
        PopupMenuItem(value: TaskView.today, child: Text('今日')),
        PopupMenuItem(value: TaskView.tomorrow, child: Text('明日')),
        PopupMenuItem(value: TaskView.week, child: Text('最近7天')),
        PopupMenuItem(value: TaskView.calendar, child: Text('日历视图')),
        PopupMenuItem(value: TaskView.quadrant, child: Text('四象限')),
        PopupMenuItem(value: TaskView.history, child: Text('历史归档')),
      ],
    );
  }
}

class _TaskCard extends StatelessWidget {
  final Task task;
  const _TaskCard({required this.task});

  @override
  Widget build(BuildContext context) {
    final provider = context.read<TaskProvider>();
    return Card(
      child: ListTile(
        leading: Checkbox(
          value: task.isCompleted,
          onChanged: (_) => provider.toggleComplete(task),
        ),
        title: Text(
          task.title,
          style: TextStyle(
            decoration: task.isCompleted ? TextDecoration.lineThrough : null,
            color: task.isCompleted ? Colors.grey : null,
          ),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(provider.countdownText(task), style: const TextStyle(fontSize: 12)),
            if (task.description.isNotEmpty)
              Text(task.description, maxLines: 1, overflow: TextOverflow.ellipsis),
            Wrap(
              spacing: 6,
              children: [
                _PriorityChip(priority: task.priority),
                ...task.tagIds.map((id) {
                  final tag = provider.tags.cast<Tag?>().firstWhere(
                        (t) => t?.id == id,
                        orElse: () => null,
                      );
                  if (tag == null) return const SizedBox.shrink();
                  return Chip(label: Text(tag.name), visualDensity: VisualDensity.compact);
                }),
              ],
            ),
          ],
        ),
        trailing: task.status == TaskStatus.completed
            ? IconButton(
                icon: const Icon(Icons.archive_outlined),
                onPressed: () => _askArchive(context, provider),
              )
            : task.status == TaskStatus.archived
                ? IconButton(
                    icon: const Icon(Icons.unarchive_outlined),
                    onPressed: () => provider.restoreTask(task.id),
                  )
                : null,
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => TaskEditScreen(task: task)),
        ),
      ),
    );
  }

  Future<void> _askArchive(BuildContext context, TaskProvider provider) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('归档任务'),
        content: const Text('是否自动归档到历史记录？'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('保留')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('归档')),
        ],
      ),
    );
    if (ok == true) await provider.archiveTask(task.id);
  }
}

class _PriorityChip extends StatelessWidget {
  final Priority priority;
  const _PriorityChip({required this.priority});

  @override
  Widget build(BuildContext context) {
    Color color;
    String label;
    switch (priority) {
      case Priority.high:
        color = Colors.redAccent;
        label = '高';
        break;
      case Priority.medium:
        color = Colors.orangeAccent;
        label = '中';
        break;
      case Priority.low:
        color = Colors.greenAccent;
        label = '低';
        break;
    }
    return Chip(
      label: Text(label, style: TextStyle(color: color.computeLuminance() > 0.5 ? Colors.black : Colors.white)),
      backgroundColor: color,
      visualDensity: VisualDensity.compact,
    );
  }
}
