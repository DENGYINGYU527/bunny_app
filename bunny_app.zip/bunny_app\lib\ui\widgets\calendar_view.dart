import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../core/models/task.dart';
import '../../core/providers/task_provider.dart';
import '../screens/task_edit_screen.dart';

class CalendarView extends StatefulWidget {
  const CalendarView({super.key});

  @override
  State<CalendarView> createState() => _CalendarViewState();
}

class _CalendarViewState extends State<CalendarView> {
  DateTime _focused = DateTime.now();
  DateTime? _selected;

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TaskProvider>();
    return Column(
      children: [
        TableCalendar<Task>(
          firstDay: DateTime(2020),
          lastDay: DateTime(2099),
          focusedDay: _focused,
          selectedDayPredicate: (d) => isSameDay(_selected, d),
          eventLoader: (day) => provider.tasks.where((t) {
            if (t.dueDate == null) return false;
            return isSameDay(t.dueDate!, day);
          }).toList(),
          onDaySelected: (sel, foc) => setState(() {
            _selected = sel;
            _focused = foc;
            provider.setSelectedDate(sel);
          }),
          calendarStyle: const CalendarStyle(
            markerDecoration: BoxDecoration(color: Colors.pinkAccent, shape: BoxShape.circle),
          ),
          headerStyle: const HeaderStyle(titleCentered: true, formatButtonVisible: false),
        ),
        Expanded(
          child: ListView(
            children: provider.visibleTasks.map((t) => ListTile(
              title: Text(t.title),
              subtitle: Text(t.dueDate == null ? '' : DateFormat('HH:mm').format(t.dueDate!)),
              leading: Checkbox(
                value: t.isCompleted,
                onChanged: (_) => provider.toggleComplete(t),
              ),
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TaskEditScreen(task: t))),
            )).toList(),
          ),
        ),
      ],
    );
  }
}
