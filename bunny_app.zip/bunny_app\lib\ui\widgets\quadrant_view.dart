import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/models/task.dart';
import '../../core/providers/task_provider.dart';
import '../screens/task_edit_screen.dart';

class QuadrantView extends StatelessWidget {
  const QuadrantView({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TaskProvider>();
    final all = provider.tasks.where((t) => t.status != TaskStatus.archived).toList();

    final q1 = all.where((t) => _isUrgent(t) && _isImportant(t)).toList();
    final q2 = all.where((t) => !_isUrgent(t) && _isImportant(t)).toList();
    final q3 = all.where((t) => _isUrgent(t) && !_isImportant(t)).toList();
    final q4 = all.where((t) => !_isUrgent(t) && !_isImportant(t)).toList();

    return Padding(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          Expanded(
            child: Row(
              children: [
                _Quadrant(title: '重要且紧急', color: Colors.red.shade100, tasks: q1, icon: Icons.crisis_alert),
                _Quadrant(title: '重要不紧急', color: Colors.orange.shade100, tasks: q2, icon: Icons.star_border),
              ],
            ),
          ),
          Expanded(
            child: Row(
              children: [
                _Quadrant(title: '紧急不重要', color: Colors.yellow.shade100, tasks: q3, icon: Icons.access_time),
                _Quadrant(title: '不紧急不重要', color: Colors.green.shade100, tasks: q4, icon: Icons.coffee),
              ],
            ),
          ),
        ],
      ),
    );
  }

  bool _isUrgent(Task t) => t.dueDate != null && t.dueDate!.difference(DateTime.now()).inDays <= 2;
  bool _isImportant(Task t) => t.priority == Priority.high;
}

class _Quadrant extends StatelessWidget {
  final String title;
  final Color color;
  final List<Task> tasks;
  final IconData icon;
  const _Quadrant({required this.title, required this.color, required this.tasks, required this.icon});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Card(
        color: color,
        margin: const EdgeInsets.all(4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Icon(icon, size: 16),
                  const SizedBox(width: 4),
                  Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                  const Spacer(),
                  Text('${tasks.length}', style: const TextStyle(fontSize: 12)),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: tasks.length,
                itemBuilder: (context, idx) {
                  final t = tasks[idx];
                  return ListTile(
                    dense: true,
                    leading: Checkbox(
                      value: t.isCompleted,
                      onChanged: (_) => context.read<TaskProvider>().toggleComplete(t),
                    ),
                    title: Text(t.title, style: const TextStyle(fontSize: 13)),
                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => TaskEditScreen(task: t))),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
