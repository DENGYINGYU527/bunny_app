// Basic placeholder test for Bunny.

import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('App loads placeholder', (WidgetTester tester) async {
    expect(true, isTrue);
  });
}
